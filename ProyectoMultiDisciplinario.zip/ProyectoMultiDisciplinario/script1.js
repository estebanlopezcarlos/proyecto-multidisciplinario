var btnElm = document.getElementById('subir');
var pElm = document.getElementById('contarClick');
var contar=0;
pElm.textContent=0;
btnElm.onclick=function(){
    contar++;
    pElm.textContent=contar;
}
function abrirCajaComentario() {
    const comentario = prompt("Escribe tu comentario:");
    if (comentario) {
        // para hacer algo con el comentario a futuro
        console.log("Comentario del usuario:", comentario);
    }
}